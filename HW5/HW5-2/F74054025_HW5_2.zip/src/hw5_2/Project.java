package hw5_2;

public class Project {
	String name;
	double budget;
	int priority;
	public int giveSalary(Salary sal)
	{
		return sal.salary;
	}

}
