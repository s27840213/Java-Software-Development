package hw5_2;

public class Worker extends Person{
	Project p = new Project();
}
