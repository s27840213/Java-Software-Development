package hw5_2;

public class Salary {
	Person p;
	Project proj;
	int salary;
}
