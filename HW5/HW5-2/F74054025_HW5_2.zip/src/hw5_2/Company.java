package hw5_2;

public class Company {
	String name;
	String phoneNum;
	double budget;
	String product;
	Person p = new Person();
	Department d = new Department();
	public void hire() {
		
	}
	public void fire() {
		
		
	}
}
