package hw5_2;

public class Product {
	String name;
	double cost;
	double weight;

}
