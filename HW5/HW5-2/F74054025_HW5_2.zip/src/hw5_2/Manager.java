package hw5_2;

public class Manager extends Person{
	Project p = new Project();
}
