package hw5_2;

public class Department {
	Manager staff = new Manager();
	Product d = new Product();
}
